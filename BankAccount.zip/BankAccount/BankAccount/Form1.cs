﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankAccount
{
    public partial class Form1 : Form
    {

        double balance = 0.00;
        int numOfDeposits = 0;
        double totalDeposits = 0.00;
        int numOfChecks = 0;
        double totalChecks = 0.00;
        int numOfServiceCharges = 0;
        double totalServiceCharges = 0.00;

        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
           
            double transactionAmount;
            try
            {
                transactionAmount = Convert.ToDouble(amountTextBox.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid amount.", "Invalid Amount", MessageBoxButtons.OK, MessageBoxIcon.Error);
                amountTextBox.Focus();
                return;
            }

            if (depositRadioButton.Checked)
            {
                balance += transactionAmount;
                numOfDeposits++;
                totalDeposits += transactionAmount;
            }
            else if (checkRadioButton.Checked)
            {
                if (balance - transactionAmount < 0)
                {
                    MessageBox.Show("Insufficient Funds.", "Insufficient Funds", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    balance -= 10.00;
                    numOfServiceCharges++;
                    totalServiceCharges += 10.00;
                }
                else
                {
                    balance -= transactionAmount;
                    numOfChecks++;
                    totalChecks += transactionAmount;
                }
            }
            else if (serviceRadioButton.Checked)
            {
                balance -= transactionAmount;
                numOfServiceCharges++;
                totalServiceCharges += transactionAmount;
            }

          
            balanceTextBox.Text = balance.ToString();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
       
            amountTextBox.Clear();
            depositRadioButton.Checked = true;
          
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void summaryButton_Click(object sender, EventArgs e)
        {
           
            string message = "Number of deposits: " + numOfDeposits + "\n";
            message += "Total amount of deposits: " + totalDeposits.ToString("C") + "\n";
            message += "Number of checks: " + numOfChecks + "\n";
            message += "Total amount of checks: " + totalChecks.ToString("C") + "\n";
            message += "Number of service charges: " + numOfServiceCharges + "\n";
            message += "Total amount of service charges: " + totalServiceCharges.ToString("C");
            MessageBox.Show(message, "Account Summary", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void depositRadioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void balanceLabel_Click(object sender, EventArgs e)
        {

        }

        private void balanceTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
